const listUrl =
  'https://gist.githubusercontent.com/niceaji/d34fcd2d593bef75c277fe1f4a0ee519/raw/6698dab524040e1f0d48d4f8282476a5e5b53640/sentences.json';
const translateUr = 'https://translate.google.com/?sl=en&tl=ko&text=';

const loading = document.querySelector('.has-text-centered has-text-dark');
const txt = document.querySelector('.title is-5');
const desc = document.querySelector('.title is-4 has-text-success');
const translate =document.querySelector('.translate');
const page = document.querySelector('.count is-size-6');
const next = document.querySelector('.button next is-medium is-primary mt-5');
const timer = document.querySelector('.has-text-centered has-text-dark');

let timeLimit = 3000; //문제당 제한시간 3초
let list =[];
let pageIndex = 0; 



fetch(listUrl).then(response => response.json()).then(data =>{
  list = shuffleArray(data);
  loading.style.display = 'none';
  console.log(list);
  showList();
}).catch(err => console.log("Sorry, error", err))

 function shuffleArray(array){
  return array.sort(() => Math.random() - 0.5);
 }

 function showList(){
        txt.innerHTML = list[pageIndex].ko;
        desc.innerHTML = list[pageIndex].en;
        desc.style.display = 'none';
        translate.style.display = 'none';
        page.innerHTML = `${pageIndex + 1}/${list.length}`;
        countUp();
        if(pageIndex == (list.length - 1)){
          next.innerHTML = 'ReStart';
        }
 }


 function countUp(){
  let count = 0;
  let index = pageIndex;
  const interval = setInterval(() =>{
    if(index != pageIndex){
      clearInterval(interval);
      return false;
    }
    count += 1;
    console.log(count);
    timer.style.width = count + '%';
    
    if(count >= 100){
      clearInterval(interval);
      desc.style.display = 'block';
      translate.style.display ='block';
      translate.setAttribute('href',`${translateUr}${list[pageIndex].en}`);

    }
  },30)
 }

 document.querySelector('.next').addEventListener('click',function(){

  if(pageIndex == (list.length - 1)){
    window.location.reload();
  }else {
    pageIndex = pageIndex +1;
    showList()
  }
 })
